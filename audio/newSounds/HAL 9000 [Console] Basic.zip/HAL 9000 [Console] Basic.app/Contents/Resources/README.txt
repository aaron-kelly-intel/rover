THE HAL 9000 SCREENSAVER
Many thanks for downloading this software.

INSTALLATION NOTES/KNOWN ISSUES

General Recommendations (Mac OS & Windows)
Please ensure you have the very latest Flash player plugin installed (http://get.adobe.com/flashplayer/). Make sure there are no Flash blockers running which can stop the screensaver from displaying. It is also recommended you disable Adblock's flash blocker setting or try AdBlock Plus.

Try these steps if you are still having trouble installing/running the screensaver:
1) Open the Flash preferences (Mac OS: System Preferences/Windows: Control Panel), and navigate to the 'Advanced' tab, click on 'Delete browsing data and settings'.
2) If running Chrome, temporarily disable Flash by typing the following address into a new tab: chrome://plugins — find the Flash plugin and disable it.
3) Close Chrome and Open Safari/Internet Explorer.
4) Open the following URL in Safari/Internet Explorer: http://helpx.adobe.com/flash-player/kb/find-version-flash-player.html — If the version installed is not the latest, update Flash.
5) The install will ask you to close Safari/Internet Explorer, but if you didn't need to update Flash, close Safari/Internet Explorer now.
6) If you disabled Flash in Chrome, re-enable it now.

(Windows only)
You must have administrator privileges and be logged in as an administrator to correctly install the HAL 9000 Screensaver on any 64-bit (x64) version of Windows.

If an installation error occurs during setup on any 32-bit (x86) version of Windows, please try right-clicking the installer and selecting "Run as Administrator" from the drop down menu.

Note: if a Mac OS or Windows system update disables The HAL 9000 Screensaver or Flash functionality, please allow time for Adobe to update the Flash player in response.

CONTACT INFORMATION

E-mail: Joe Mackenzie <joey@halproject.com>
Twitter: @TheHALProject <http://www.twitter.com/TheHALProject>
Web: The HAL Project <http://www.halproject.com>

LICENSE
Please read & accept the END USER LICENSE AGREEMENT before installing.

(Basic Edition)
The HAL 9000 Screensaver (Basic Edition) is free to distribute (as is) when a URL referral to The HAL Project <http://www.halproject.com> is placed next to any download link.

(Advanced Edition)
You may not distribute copies of the HAL 9000 Screensaver (Advanced Edition).

CREDITS
Created by Joe Mackenzie.
Copyright (c) 2014, The HAL Project.
